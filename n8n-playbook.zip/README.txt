n8n Production Playbook
=======================
by ErgeneAI

CONTENTS:
- n8n-playbook.pdf (8 chapters, production deployment guide)
- 5 production n8n workflow JSON files

INSTALLATION:
1. Read the PDF guide first
2. Import workflows to your n8n instance
3. Configure credentials (all marked with [CONFIGURE])
4. Update webhook URLs for your domain

REQUIREMENTS:
- n8n 1.0+ (Docker or self-hosted)
- Node.js 18+ (if self-hosting)
- PostgreSQL (recommended for production)

FIRST STEPS:
1. Chapter 1: Set up production deployment
2. Chapter 2: Configure error handling
3. Import and test each workflow individually
4. Deploy to production

SUPPORT:
Documentation: https://ergene.gumroad.com/l/zero-to-ai-agent
