import importlib.util
from pathlib import Path
BASE=Path(__file__).resolve().parents[1]/"governance"
def load(name):
 s=importlib.util.spec_from_file_location(name,BASE/f"{name}.py");m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
CompletionProtocol=load("completion_protocol").CompletionProtocol
ResponseQualityFilter=load("response_quality_filter").ResponseQualityFilter
PushbackPolicy=load("pushback_policy").PushbackPolicy
RevenueContributionTracker=load("revenue_contribution_tracker").RevenueContributionTracker

def test_partial_task_creates_one_open_item(tmp_path):
 p=CompletionProtocol(tmp_path/"open.json");p.review_and_record("t1","finans","Eksik takip var","Teklif kontrolü","Teklifi ara")
 p.review_and_record("t1","finans","Hâlâ eksik","Teklif kontrolü","Teklifi ara")
 assert len(p.pending_for("finans"))==1

def test_completed_task_closes_open_item(tmp_path):
 p=CompletionProtocol(tmp_path/"open.json");p.review_and_record("t1","finans","Eksik","Takip")
 p.review_and_record("t1","finans","Tamam")
 assert not p.pending_for("finans")

def test_response_filter_puts_decision_first():
 out=ResponseQualityFilter().enforce("Öncelikle uzun bir açıklama var. İkinci cümle. Üçüncü cümle.","Şimdi pilot test yapalım.")
 assert out.startswith("Sonuç: Şimdi pilot test yapalım.")

def test_pushback_blocks_empty_praise():
 out=PushbackPolicy().enforce("Fiyatı yarıya indirelim", "Harika fikir")
 assert "Risk:" in out and "Alternatif:" in out

def test_pushback_ignores_plain_question():
 assert PushbackPolicy().enforce("Bugün hava nasıl?","Harika") == "Harika"

def test_revenue_no_contribution_is_explicit(tmp_path):
 t=RevenueContributionTracker(tmp_path/"revenue.json");r=t.build_section("2026-W28")
 assert r["conclusion"]=="Bu hafta gelire doğrudan katkı yok."

def test_revenue_week_comparison(tmp_path):
 t=RevenueContributionTracker(tmp_path/"revenue.json");t.build_section("2026-W27",100)
 r=t.build_section("2026-W28",150,advancing_actions=[{"type":"qualified_lead"}])
 assert r["comparison"]["direct_revenue_change"]==50
