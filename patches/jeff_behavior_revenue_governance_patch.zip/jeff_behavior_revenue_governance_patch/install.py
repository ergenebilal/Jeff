from __future__ import annotations
import argparse,json,shutil
from pathlib import Path

CANDIDATES={
 "director_agent":["director_agent.py"],
 "weekly_briefing":["weekly_briefing.py"],
 "soul":["SOUL.md","soul.md","soul.txt","system_prompt.md","prompt.md"],
 "response":["response.py","chat.py","agent.py","hermes_agent.py"]
}
def find(root:Path,names:list[str])->list[str]:
    found=[]
    for name in names:
        found += [str(p) for p in root.rglob(name) if ".git" not in p.parts and "legacy" not in p.parts]
    return sorted(set(found))[:20]
def main():
    ap=argparse.ArgumentParser();ap.add_argument("--project-root",required=True);ap.add_argument("--dry-run",action="store_true");args=ap.parse_args()
    root=Path(args.project_root); package=Path(__file__).resolve().parent
    manifest={"project_root":str(root),"discovered":{k:find(root,v) for k,v in CANDIDATES.items()},"required_hooks":["CompletionProtocol.review_and_record","ResponseQualityFilter.enforce","PushbackPolicy.enforce","RevenueContributionTracker.build_section"]}
    print(json.dumps(manifest,ensure_ascii=False,indent=2))
    if args.dry_run:return
    target=root/"governance"/"behavior_revenue";target.mkdir(parents=True,exist_ok=True)
    for file in (package/"governance").glob("*.py"): shutil.copy2(file,target/file.name)
    (root/"behavior_revenue_governance_manifest.json").write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding="utf-8")
    print(f"Installed: {target}")
if __name__=="__main__":main()
