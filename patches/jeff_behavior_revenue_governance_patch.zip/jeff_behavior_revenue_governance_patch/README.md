# JEFF Davranış ve Gelir Governance Paketi

Bu paket dört yeteneği ekler:

1. Görev kapatma denetimi ve açık görev kaydı
2. Sonuç önce yanıt kalite filtresi
3. Kanıtsız övgüyü engelleyen pushback politikası
4. Haftalık gelir katkısı ve karşılaştırma kaydı

## Entegrasyon yöntemi

Paket aktif dosya yollarını varsaymaz. `install.py`, mevcut proje içinde ilgili modülleri bulur, yalnızca yeni governance dosyalarını kopyalar ve `integration_manifest.json` üretir. Aktif `director_agent.py`, SOUL veya briefing katmanına otomatik müdahale etmez.

Önce dry-run:

```bash
cd /opt/hermes/jeff_v2
python3 behavior_revenue_governance/install.py --project-root /opt/hermes/jeff_v2 --dry-run
```

Sonra dosyaları yükle:

```bash
python3 behavior_revenue_governance/install.py --project-root /opt/hermes/jeff_v2
python3 -m pytest behavior_revenue_governance/tests -v
```

## Manuel bağlama noktaları

Manifest çıktısı ile tespit edilen aktif dosyaya aşağıdaki çağrılar eklenir:

- Task tamamlanırken: `CompletionProtocol.review_and_record(...)`
- Kullanıcıya yanıt dönmeden önce: `ResponseQualityFilter.enforce(...)`
- Fikir/strateji yanıtında: `PushbackPolicy.enforce(...)`
- Haftalık briefing üretilirken: `RevenueContributionTracker.build_section(...)`

Bu paketin kodu doğrudan kullanılabilir; uygulamanın gerçek çağrı zincirine bağlanmak için manifestteki aktif giriş noktası doğrulanmalıdır.

## Güvenlik

- Secret/token okumaz veya yazmaz.
- Dış iletişim başlatmaz.
- Mevcut canlı dosyaları otomatik değiştirmez.
- Açık görev ve gelir kayıtlarını JSON formatında saklar.

## Geri alma

```bash
rm -rf /opt/hermes/jeff_v2/governance/behavior_revenue
rm -rf /opt/hermes/jeff_v2/behavior_revenue_governance
```

Entegrasyon yapılmış aktif dosyalarda değişiklik varsa, OpenCode yedeğine geri dönün.
