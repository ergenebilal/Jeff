from __future__ import annotations
import re
class ResponseQualityFilter:
    FILLERS=("merhaba", "tabii", "elbette", "öncelikle", "şunu belirtmek gerekir", "harika soru")
    def enforce(self,text:str,decision:str="") -> str:
        text=(text or "").strip()
        if not text:return text
        paragraphs=[p.strip() for p in text.split("

") if p.strip()]
        first=paragraphs[0] if paragraphs else text
        if decision and decision.lower() not in first.lower(): paragraphs.insert(0,f"Sonuç: {decision.strip()}")
        elif not re.search(r"(sonuç|karar|öneri|durum)\s*:",first.lower()):
            sentences=re.split(r"(?<=[.!?])\s+",first)
            if len(sentences)>2: paragraphs[0]=" ".join(sentences[:2])
        result="

".join(paragraphs)
        for filler in self.FILLERS: result=re.sub(rf"(?i)^\s*{re.escape(filler)}[,:! ]*", "", result)
        return result.strip()
