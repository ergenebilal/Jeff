from __future__ import annotations
import json
from datetime import datetime,timezone
from pathlib import Path
from typing import Any
class RevenueContributionTracker:
    NO_CONTRIBUTION="Bu hafta gelire doğrudan katkı yok."
    def __init__(self,path:str|Path="/opt/hermes/jeff_v2/memory_data/finance_revenue_contributions.json"):
        self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True)
        if not self.path.exists():self.path.write_text(json.dumps({"weeks":{}},ensure_ascii=False,indent=2),encoding="utf-8")
    def _read(self):return json.loads(self.path.read_text(encoding="utf-8"))
    def _write(self,data):self.path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    def build_section(self,week:str,direct_revenue:float=0.0,closing_actions:list[dict[str,Any]]|None=None,advancing_actions:list[dict[str,Any]]|None=None,evidence:list[str]|None=None,next_focus:str="")->dict[str,Any]:
        closing_actions=closing_actions or [];advancing_actions=advancing_actions or [];evidence=evidence or []
        conclusion="Gelire doğrudan katkı kaydedildi." if direct_revenue>0 else self.NO_CONTRIBUTION
        data=self._read();prior_keys=sorted(k for k in data["weeks"] if k<week);previous=data["weeks"].get(prior_keys[-1],{}) if prior_keys else {}
        section={"week":week,"direct_revenue":direct_revenue,"revenue_closing_actions":closing_actions,"revenue_advancing_actions":advancing_actions,"evidence":evidence,"conclusion":conclusion,"next_week_revenue_focus":next_focus,"qualified_leads":sum(1 for x in advancing_actions if x.get("type")=="qualified_lead"),"closed_offers":sum(1 for x in closing_actions if x.get("type")=="closed_offer"),"saved_at":datetime.now(timezone.utc).isoformat()}
        section["comparison"]={"direct_revenue_change":direct_revenue-float(previous.get("direct_revenue",0)),"advancing_action_change":len(advancing_actions)-len(previous.get("revenue_advancing_actions",[])),"previous_week":previous.get("week")}
        data["weeks"][week]=section;self._write(data);return section
