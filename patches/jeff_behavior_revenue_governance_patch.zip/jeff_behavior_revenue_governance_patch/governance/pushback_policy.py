from __future__ import annotations
import re
class PushbackPolicy:
    IDEA_HINTS=("fikir","öner","yapalım","strateji","plan","fiyat","kampanya","yatırım","başlat")
    EMPTY_PRAISE=("harika fikir","çok iyi fikir","mükemmel fikir","kesinlikle doğru","harika")
    def applies(self,user_text:str)->bool:
        low=(user_text or "").lower();return any(x in low for x in self.IDEA_HINTS)
    def enforce(self,user_text:str,response:str)->str:
        if not self.applies(user_text):return response
        low=(response or "").lower()
        has_challenge=any(x in low for x in ("risk", "alternatif", "veri", "ölç", "varsayım", "test"))
        starts_praise=any(low.strip().startswith(x) for x in self.EMPTY_PRAISE)
        if has_challenge and not starts_praise:return response
        prefix="Karar: Fikir test edilebilir; ancak kanıtsız doğrudan onay vermek doğru değil. Risk: Beklenen sonuç doğrulanmadan kaynak kaybı oluşabilir. Alternatif: Küçük, ölçülebilir bir pilotla başlayalım."
        cleaned=re.sub(r"(?i)^(harika fikir|çok iyi fikir|mükemmel fikir|kesinlikle doğru|harika)[,! .]*", "", response or "").strip()
        return prefix+("

"+cleaned if cleaned else "")
