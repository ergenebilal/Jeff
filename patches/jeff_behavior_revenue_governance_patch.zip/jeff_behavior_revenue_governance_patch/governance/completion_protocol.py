from __future__ import annotations
import json
from datetime import datetime,timezone
from pathlib import Path
from typing import Any

class CompletionProtocol:
    def __init__(self,path:str|Path="/opt/hermes/jeff_v2/memory_data/open_tasks.json"):
        self.path=Path(path);self.path.parent.mkdir(parents=True,exist_ok=True)
        if not self.path.exists():self._write({"open_tasks":[],"history":[]})
    def _read(self):return json.loads(self.path.read_text(encoding="utf-8"))
    def _write(self,data):self.path.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    def review_and_record(self,task_id:str,director:str,review:str,remaining_work:str="",next_action:str="",blocked:bool=False,priority:str="normal")->dict[str,Any]:
        status="blocked" if blocked else ("partial" if remaining_work.strip() else "completed")
        now=datetime.now(timezone.utc).isoformat();record={"task_id":task_id,"director":director,"completion_status":status,"completion_review":review,"remaining_work":remaining_work,"next_action":next_action,"reviewed_at":now}
        data=self._read();data["history"].append(record)
        if status in {"partial","blocked"}:
            existing=next((x for x in data["open_tasks"] if x["source_task_id"]==task_id and x["status"]=="open"),None)
            if existing: existing.update({"description":remaining_work,"next_action":next_action,"priority":priority,"updated_at":now,"status":status})
            else:data["open_tasks"].append({"id":f"open_{task_id}","source_task_id":task_id,"director":director,"description":remaining_work,"next_action":next_action,"priority":priority,"status":status,"created_at":now,"updated_at":now})
        else:
            for item in data["open_tasks"]:
                if item["source_task_id"]==task_id and item["status"] in {"open","partial","blocked"}:item["status"]="completed";item["updated_at"]=now
        self._write(data);return record
    def pending_for(self,director:str)->list[dict[str,Any]]:
        return [x for x in self._read()["open_tasks"] if x["director"]==director and x["status"] in {"open","partial","blocked"}]
